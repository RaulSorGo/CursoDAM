class Raton():
    x = 0
    y = 0
    mover = False